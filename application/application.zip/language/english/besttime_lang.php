<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['bestme_applications'] = "Applications";
$lang['bestme_ask_an_expert'] = "Ask an expert";
$lang['bestme_best_advice'] = "Best Advice";
$lang['besttime_field_required'] = "This field is required";

$lang['besttime_games'] = "Games";
$lang['besttime_other_ideas'] = " You will also like these …";

$lang['besttime_name'] = "Your name";
$lang['besttime_email'] = "Email address";

$lang['besttime_thanks'] = "Thank you for participation ";
$lang['besttime_answer'] = "You will be answered as soon as possible";
$lang['besttime_other_quizes'] = "Other Quizzes";

$lang['besttime_will_be_answered'] = "Will be answered by an expert life from Nestlé  and helps you in response to your question";


$lang['besttime_answers'] = " Hiding your talents in communicating with people: you have a strange ability to persuade, you have the hearts of those around you, and your words are heard and your order choice all around you and maybe that caused your solidity, personality and very sensitive at the same time";
$lang['besttime_get_gifts_not_housed'] = " Get gifts not housed";
$lang['besttime_Perform_the_test_again'] = "Repeat Quiz";

/* Location: ./application/controllers/welcome.php */