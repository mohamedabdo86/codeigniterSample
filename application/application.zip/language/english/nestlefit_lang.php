<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*Nestle Fit App. */
$lang['nestlefit_nestle_fit'] = "Nestlé Fit";
$lang['nestlefit_calc_calories'] = "Calculate Food Calories";
$lang['nestlefit_burn_rate'] = "Activity and Rate Burning";
