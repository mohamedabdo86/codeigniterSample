<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$lang['bestmom_applications'] = "Applications";
$lang['bestmom_ask_an_expert'] = "Ask an expert";
$lang['bestmom_news_letter_signup'] = "Newsletter Sign Up";
$lang['bestmom_news_letter_signup_desc'] = "Subscribe to receive the latest news & information on health, nutrition and your child’s development";
$lang['bestmom_my_pregnancy'] = " My pregnancy";
$lang['bestmom_my_baby'] = " My baby ";
$lang['bestmom_growth_and_upbringing_of_my_child'] = " Growth and upbringing of my child ";
$lang['bestmom_all_you_need_to_know_about_feeding_your_baby_and_health'] = "  feeding your baby and health";
$lang['bestmom_take_care_of_my_baby']= " Take care of my baby";
$lang['bestmom_every_day_advice'] = " every day advice";
$lang['bestmom_my_pregnancy_evaluation'] = "pregnancy evaluation ";
$lang['bestmom_Waiting_for_delivery'] = " waiting for delivery";
$lang['bestmom_subscribe_now'] = "Subscribe Now";

$lang['bestmom_world_health_organization'] = "World Health Organization recommends the importance of breastfeeding for 6 months";
$lang['bestmom_the_pregenancy_journy_film'] = " The pregenancy journy film ";


/* Location: ./application/controllers/welcome.php */
