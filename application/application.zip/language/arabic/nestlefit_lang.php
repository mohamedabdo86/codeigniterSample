<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*Nestle Fit App. */
$lang['nestlefit_nestle_fit'] = "نستله فيت";
$lang['nestlefit_calc_calories'] = "حاسبة سعرات الطعام";
$lang['nestlefit_burn_rate'] = "النشاط ومعدل الحرق";