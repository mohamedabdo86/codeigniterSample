<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*Website Main Attr. */
$lang['newsletter_please_wait'] = "برجاء الانتظار";

$lang['newsletter_service'] = "خدمة البريد الالكترونى";

$lang['newsletter_send_button'] = "ارسل";

$lang['newsletter_title'] = "عنوان البريد:";
$lang['newsletter_enter_email'] = "البريد الالكتروني";
$lang['newsletter_pregnancy_month'] = "انتى حامل فى الشهر الكام ؟";
$lang['newsletter_child_month'] = "طفلك عنده كام شهر ؟";
$lang['newsletter_child_month_count'] = "شهر";

$lang['newsletter_validate_email_empty'] = "من فضلك ادخل بريدك الالكتروني .";
$lang['newsletter_validate_email_format'] = "من فضلك ادخل البريد الالكترونى بشكل صحيح .";

$lang['newsletter_validate_status_1'] = "تم إضافتك الي المجموعة البريدية. يمكنك اغلاق هذه الصفحة الان";
$lang['newsletter_validate_status_0'] = "لقد تم إشتراكك في المجموعة البريدية من قبل";
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */