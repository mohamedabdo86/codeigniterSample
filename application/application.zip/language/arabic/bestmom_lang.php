<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['bestmom_applications'] = "تطبيقات نستله";
$lang['bestmom_ask_an_expert'] = "إسألي خبير نستله";
$lang['bestmom_news_letter_signup'] = "خدمة البريد الالكتروني";
$lang['bestmom_news_letter_signup_desc'] = "سجلي معانا عشان نمدك باخر المعلومات عن صحة و تغذية و تطور طفلك";
$lang['bestmom_my_pregnancy'] = " حملى";
$lang['bestmom_my_baby'] = " طفلى الرضيع";
$lang['bestmom_growth_and_upbringing_of_my_child'] = " نمو و تنشئة طفلي";
$lang['bestmom_all_you_need_to_know_about_feeding_your_baby_and_health'] = " كل ما تحتاجين معرفته عن تغذية طفلك وصحتة";
$lang['bestmom_take_care_of_my_baby']= " العناية بطفلي";
$lang['bestmom_every_day_advice'] = " كل يوم نصيحة";
$lang['bestmom_my_pregnancy_evaluation'] = "تطور  حملى ";
$lang['bestmom_Waiting_for_delivery'] = " فى انتظار مولودى";
$lang['bestmom_subscribe_now'] = "إشتركى الآن";

$lang['bestmom_world_health_organization'] = "  توصى منظمة الصحة العالمية بأهمية  الرضاعة الطبيعية لمدة 6 شهور";
$lang['bestmom_the_pregenancy_journy_film'] = " فيلم تطور الحمل ";



/* Location: ./application/controllers/welcome.php */
