<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['bestme_applications'] = "تطبيقات نستلة";
$lang['bestme_ask_an_expert'] = "إسألي خبير نستلة";
$lang['bestme_best_advice'] = "أحسن نصيحة";

$lang['besttime_field_required'] = "يرجي ادخال جميع البيانات";

$lang['besttime_games'] = "ألعاب";
$lang['besttime_other_ideas'] = " أفكار اخرى لجمالك";

$lang['besttime_thanks'] = "شكرا على المشاركة";
$lang['besttime_answer'] = " سوف يتم الرد عليك فى أقرب وقت ممكن";

$lang['besttime_name'] = " اسمك";
$lang['besttime_email'] = "البريد الالكترونى";
$lang['besttime_other_quizes'] = "إختبارات أخرى";

$lang['besttime_will_be_answered'] = "  سوف يتم الرد عن طريق خبير الحياة من نستله ويساعدك فى الرد على سؤالك";


$lang['besttime_answers'] = "تختبئ مواهبك في التواصل مع الناس:لديك قدرة رهيبة بالاقناع، وتملكين القلوب من حولك، وكلامك مسموع واستشارتك أمر يختاره كلّ من حولك وربّما هذا ناتج عن صلابتك وشخصيتك المحببة والحساسة كثيراً في الوقت عينه.";
$lang['besttime_get_gifts_not_housed'] = " تفرحك الهدايا بغير إيوانها";
$lang['besttime_Perform_the_test_again'] = "إجراء الاختبار مرة أخرى";



/* Location: ./application/controllers/welcome.php */