<div class="sections_wrapper_margin" >
    
    
  		  <div class="video_wrapper_width home_widget float_left "  style="border:solid 1px #a6a6a6" >
            
            <div class="title  white_color " style="background:#a6a6a6"  >
                <div class="white_color">إعلانات نستلة</div>
            </div>
            
            <ul class="list_small_withimage gray_color">
                    <li><a href="#"><img class="float_left" src="http://cdn.pimg.co/p/85x47/858652/fff/img.png" />
                    <div class="margin_5 float_left" >&nbsp;</div>
                    <div class=" float_left articletitle">طريقة عمل بيكاتا بالمشروم و الخضروات</div>
                    </a></li>
                    <li><a href="#"><img class="float_left" src="http://cdn.pimg.co/p/85x47/858652/fff/img.png" />
                    <div class="margin_5 float_left" >&nbsp;</div>
                    <div class=" float_left articletitle">طريقة عمل بيكاتا بالمشروم و الخضروات</div>
                    </a></li>
                    <li><a href="#"><img class="float_left" src="http://cdn.pimg.co/p/85x47/858652/fff/img.png" />
                    <div class="margin_5 float_left" >&nbsp;</div>
                    <div class=" float_left articletitle">طريقة عمل بيكاتا بالمشروم و الخضروات</div>
                    </a></li>
                    <li><a href="#"><img class="float_left" src="http://cdn.pimg.co/p/85x47/858652/fff/img.png" />
                    <div class="margin_5 float_left" >&nbsp;</div>
                    <div class=" float_left articletitle">طريقة عمل بيكاتا بالمشروم و الخضروات</div>
                    </a></li>
                   
                    
                </ul>
            
                <div class="triangle gray_borderbottom_color" style="border-bottom-color:#a6a6a6" ></div>
                <div class="plus_sign white_color"><a href="#">+</a></div>
                
			</div><!-- End of videos -->
            
            <div style="height:310px" class="float_left homesperator_width" ></div>
            
            <div class="social_wrapper_width home_widget float_left "  style="border:solid 1px #536c9f;" >
            
            <div class="title  white_color" style="background:#536c9f"  >
                <div class="white_color">فيس بوك</div>
            </div>
 
			</div><!-- End of facebook -->
            
            <div style="height:310px" class="float_left homesperator_width" ></div>
            
            <div class="social_wrapper_width home_widget float_left "  style="border:solid 1px #7bd8ff" >
            
            <div class="title  white_color " style="background:#7bd8ff"  >
                <div class="white_color">تويتر</div>
            </div>
            
            <div ><a style="color:#7bd8ff; margin-top:60px" class=" margin_15 float_left" href="">@NestleEgypt</a></div>
            <div class="clear">  </div>
            <ul class="list_small_titleonly gray_color" style="top:0px" >
                    <li style="border-bottom:solid 1px #ccc; min-height:50px"><a class="gray_color">طريقة عمل بيكاتا بالمشروم و الخضروات</a></li>
                    <li><a class="gray_color">طريقة عمل بيكاتا بالمشروم و الخضروات</a></li>
			</ul>
             
                
			</div><!-- End of facebok -->
            
    
    
    
    
    <div class="clear"></div>
    </div>