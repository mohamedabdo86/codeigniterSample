<div class="clear"></div>

<div class="inner_title_wrapper">

<div class="sections_wrapper_padding white_background_color" >
<h1 class="<?php echo $current_section_color ?>">التسجيل</h1>
</div>

</div><!-- End of inner_title_wrapper -->
<div class="white_background_color" style="height:150px;">
	<h3 style="text-align:center; padding:20px">Your registration is successfully submitted</h3>
</div>
