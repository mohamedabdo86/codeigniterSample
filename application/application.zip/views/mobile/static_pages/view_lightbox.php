<style>

#newsletter_form_main_wrapper
{
	width:100% !important;
	overflow:hidden !important;
/*	position:relative;*/
	padding:15px;
	
}
.fancybox-inner{
	width:100% !important;
	overflow:hidden !important;
	}
body.arabic #newsletter_form_main_wrapper
{
	direction:rtl;
}
</style>
<div class="row">
<div id="newsletter_form_main_wrapper">

<div class="col-xs-12 col-sm-12 col-md-12"><h3><?php echo $title; ?></h3></div>
<div class="col-xs-12 col-sm-12 col-md-12"><p><?php echo $desc; ?></p></div>
</div>
</div>