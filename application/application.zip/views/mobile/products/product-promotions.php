<div class="products container">
    <div class="row">
        <div class="col-xs-8 offers-details">

            <img src="http://placehold.it/800x200&text=FooBar6" class="img-responsive border-color"/>

        </div> 
        <div class="col-xs-4 product-offers">    
            <h2> عروض نيدو </h2>
        </div>
    </div>
</div> 