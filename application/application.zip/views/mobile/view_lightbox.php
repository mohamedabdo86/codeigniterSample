<style>

#newsletter_form_main_wrapper
{
	width:520px;
	position:relative;
	padding:15px;
	
}
body.arabic #newsletter_form_main_wrapper
{
	direction:rtl;
}
</style>

<div id="newsletter_form_main_wrapper">
<h3><?php echo $title; ?></h3>
<p><?php echo $desc; ?></p>
</div>