<?php

$this->load->view('mobile/template/header');
$this->load->view('mobile/'.$target_page);
$this->load->view('mobile/template/footer');
