<link rel="stylesheet" href="<?php echo base_url_mobile("js/jquery.mobile/jquery.mobile-1.4.5.css"); ?>" />

<link rel="stylesheet/less" type="text/css" href="<?php echo base_url_mobile("less/jquery-mobile-override.less"); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>js/fancybox/jquery.fancybox.css?v=2.1.4" media="screen" />

<!-- Add Button helper (this is optional) -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>js/fancybox/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
<!-- Add Thumbnail helper (this is optional) -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>js/fancybox/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />

<link rel="stylesheet" href="//fonts.googleapis.com/earlyaccess/droidarabickufi.css">
<link rel="stylesheet" href="<?php echo base_url_mobile("css/bootstrap.min.css"); ?>">

<?php /*?><link rel="stylesheet" href="<?php echo base_url_mobile("css/main-style.css"); ?>"><?php */?>
<link rel="stylesheet/less" type="text/css" href="<?php echo base_url_mobile("less/main-style.less"); ?>">

<link rel="stylesheet/less" type="text/css" href="<?php echo base_url_mobile("css/mwidget.css"); ?>">
<!--<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("js/elasticslide/elastislide.css"); ?>">-->

<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("js/idangerous-swiper/idangerous.swiper.css"); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/best-cook.css"); ?>">

<!--Start Style date picker-->

<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/jquery.mobile.datepicker.css"); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/jquery.mobile.datepicker.theme.css"); ?>">
<!--End Style date picker-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/ask-expert.css"); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("js/slick/slick.css"); ?>">


<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/responsive-styles.css"); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/style.css"); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile("css/fonts.css"); ?>">
<?php /*?><link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile('css/jquery.mobile-1.3.0.min.css');?>" /><?php */?>
<?php /*?><link rel="stylesheet" type="text/css" href="<?php echo base_url_mobile('css/mobipick.css'); ?>" /><?php */?>


