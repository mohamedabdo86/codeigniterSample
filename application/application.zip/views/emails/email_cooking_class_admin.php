<span id="name"><?php echo $name?></span>
<span id="email"><?php echo $email?> </span>
<span id="phone"><?php echo $members_phone?></span>
<span id="mobile"><?php echo $member_mobile?></span>
<span id="birthdate"><?php echo $members_birthdate?></span>
<span id="class_title"><?php echo $title?> </span>
<span id="class_day"><?php echo $lesson_day?></span>