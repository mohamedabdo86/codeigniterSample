<span id="section"><?php echo $name?></span>
<span id="email"><?php echo $email?> </span>
<span id="message"><?php echo $message?></span>