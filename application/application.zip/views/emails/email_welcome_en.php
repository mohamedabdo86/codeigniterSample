<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link />
</head>

<body style="margin:0; padding:0; font-family:Tahoma, Geneva, sans-serif; font-size:14px;" >


<table width="500" border="0" cellspacing="0" cellpadding="0" style="background:#fbf7c7;margin:0px auto;">
  <tr height="75">
    <td>
    <div style="width:100%; background-color:#fff200; border-top:5px solid #6d6d6d; border-bottom:#212c64 solid 5px">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="48%" align="left" style="padding:10px;"> welcome  </td>
        <td width="13%"><div style="width:1px; height:75px; background:#FFF"></div></td>
        <td width="35%" height="75"><img src="<?php echo base_url();?>images/emails/nestle_logo.png " /></td>
      </tr>
    </table>
    </div>
    </td>
  </tr>
  <tr height="35">
    <td height="35" align="center" valign="middle" style="font-size:11px">your account has been activated,Now you can use your account and participate in the site</td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>images/emails/welcome.png"  width="500" height="485" border="0" usemap="#Map" /></td>
  </tr>
  <tr>
    <td align=""  >
    <div style="margin:0px 60px;">
    <p style="text-align:left;margin-left:10px"> edit your information <span style="margin-left:120px;color:#253067"><a href="<?php echo site_url('my_corner/edit_profile/info'); ?>" style="text-decoration:none;">click here</a></span></p>
   
    <p style="text-align:left;margin-left:10px"> add new recipes<span style="margin-left:150px;color:#253067"><a href="<?php echo site_url('best_cook/upload_recipe'); ?>" style="text-decoration:none;">click here</a> </span></a> </p>
    </div>
  
    </td>
  </tr>
  <tr>
    <td>
   
    </td>
  </tr>
   <tr>
    <td bgcolor="212c64" height="30px">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
     <tr>
     <td width="5%">&nbsp;</td>
      <td width="55%" align="left"><a href="<?php echo site_url();?>" style="color:#FFFFFF;text-decoration:none;margin-right:10px;">www.mynestle.com.eg</a></td>
      <td width="5%">&nbsp;</td> 
     <td width="15%"><a href="https://www.facebook.com/NestleEgypt"><img src="<?php echo base_url();?>images/emails/facebook_icon.png" align="right" /></a></td>
     <td width="5%">&nbsp;</td>
     <td width="15%"><a href="https://www.youtube.com/user/NestleEgypt"><img src="<?php echo base_url();?>images/emails/youtube_icon.png" align="absbottom" /></a></td>
      </tr>
	</table>
	
    </td>
  </tr>
   
</table>




<map name="Map" id="Map">
  <area shape="rect" coords="79,435,163,481" href="<?php echo site_url('best_time');?>" alt="link4" />
  <area shape="rect" coords="86,299,177,356" href="<?php echo site_url('best_me');?>" alt="link3" />
  <area shape="rect" coords="80,196,163,244" href="<?php echo site_url('best_cook');?>" alt="link2"/>
  <area shape="rect" coords="87,83,159,130" href="<?php echo site_url('best_mom');?>" alt="link1"/>
</map>
</body>
</html>
