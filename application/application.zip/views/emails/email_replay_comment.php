<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Replay Comment</title>
</head>
<body>
  <table width="800" height="600">
  <tr>
    <td width="800" align="right"><img src="<?php echo base_url();?>images/emails/activiation_header_ar.jpg" usemap="#logo" /></td>
    <map name="logo">
  		<area shape="rect" coords="511,29,722,114" alt="nestle" target="_blank" href="<?php echo site_url('welcome'); ?>">
	</map>
  </tr>
  <tr>
  	<td width="800" height="324">
    <table width="800" height="324">
    <tr>
    	<td width="800" height="50" align="right"><h2 style="color:#1324A3;font-size:20px !important;">مرحبا رانيا</h2></td>
    </tr>
    <tr>
    	<td width="800" height="50" align="right"><h2 style="color:#1324A3;">لقد تم الرد على إستفسارك من قبل خبيرة التغذية من نستله </h2></td>
    </tr>
    <tr>
    	<td width="800">
        <table width="800">
          <tr>
            <td align="left"><img src="<?php echo base_url();?>images/emails/question_mark.png"  width="120" height="170"/></td>
            <td width="500">
            	<div style="width:450px; float:right; padding-right:10px;text-align:right;">
                <p style="color:#000;font-weight:bold;font-size:16px;"> البهرات وفوائدها وطريقة استخدامها </p>
            	<p style="color:#999;"> لمشاهدة الرد  <a style="color:#900;font-weight:bold;" href="#">اضغط هنا </a>  &nbsp;&nbsp;&nbsp; 
                 أسئلة أخرى <a style="color:#900;font-weight:bold;" href="#">اضغط هنا </a> </p>
                </div>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        </td>
    </tr>
    </table>
    </td>
  </tr>
  <tr>
    	<td> <img usemap="#footer" src="<?php echo base_url();?>images/emails/activation_footer.png" /> </td>
        <map  name="footer" id="imgmap2014612132035" name="imgmap2014612132035">
        <area shape="rect" alt="" coords="60,1,90,30" href="https://www.facebook.com/NestleEgypt" target="" />
		<area shape="rect" alt="" coords="608,8,762,25" href="<?php echo site_url('welcome');?>" target="" />
        <area shape="rect" alt="twitter" title="" coords="26,1,55,32" href="https://www.youtube.com/user/NestleEgypt" target="_blank" />
        <area shape="rect" alt="editprofile" title="" coords="567,43,622,50" href="<?php echo site_url('my_corner/profile');?>" target="" />
        <area shape="rect" alt="nomessage" title="" coords="483,53,535,67" href="<?php echo site_url('my_corner/unsubscribe_newsletter/'.$this->members->members_salt.''); ?>" target="" />
        <area shape="rect" alt="nomessage" title="" coords="600,70,661,84" href="<?php echo site_url('contact_us'); ?>" target="" />
        
        </map>
    </tr>
  
</table>   
<style>
  	@import url(http://fonts.googleapis.com/earlyaccess/droidarabickufi.css); 
	h2, h3, p{
		font-family: 'Droid Arabic Kufi', serif;
	}
	h2{
		font-size:16px;
	}
	h3{
		font-size:14px;
	}
  </style>

</body>
</html>