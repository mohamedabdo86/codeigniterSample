<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Upload Recipe</title>
</head>
<body>
  <table width="800" height="600">
  <tr>
    <td width="800" align="right"><img src="<?php echo base_url();?>images/emails/email_header.png" usemap="#logo" /></td>
    <map name="logo">
  		<area shape="rect" coords="511,29,722,114" alt="nestle" target="_blank" href="<?php echo site_url('welcome'); ?>">
	</map>
  </tr>
  <tr>
  	<td width="800" height="324">
    <table width="800" height="324">
    <tr>
    	<td width="800" height="50" align="right"><h2 style="color:#1324A3; font-size:20px !important;">مرحبا رانيا</h2></td>
    </tr>
    <tr>
    	<td width="800" height="50" align="right"><h2 style="color:#1324A3;">تم إضافة <span style="color:#F00"> 100 </span> نقطة الى حسابك وذلك إضافة تعليق على المقال</h2></td>
    </tr>
    <tr>
    	<td width="800">
        <table width="800">
          <tr>
            <td align="left"><img src="<?php echo base_url();?>images/emails/coins.png"  width="160" height="200"/></td>
            <td align="right" width="600">
            	<div style="width:287px; float:right; padding-right:10px;text-align:right;">
                <p style="color:#000;font-weight:bold;font-size:14px;"> البهرات وفوائدها وطريقة استخدامها </p>
            	<p style="color:#999;">مشاهدة المقال.. <a style="color:#900;font-weight:bold;" href="#">اضغط هنا </a> </p>
                </div>
            </td>
            <td align="right" width="200"><img src="https://www.mynestle.com.eg/images/Recipes/1a9a07ed-c13a-497f-b750-def782edf856.jpg" width="200" height="150" align="right" /></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        </td>
    </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td width="800" align="right"><img src="<?php echo base_url();?>images/emails/email_footer.png" usemap="#footer" /></td>
    <map name="footer">
  		<area shape="rect" coords="59,35,90,66" alt="Facebook" href="https://www.facebook.com/NestleEgypt" target="_blank">
        <area shape="rect" coords="25,36,56,66" alt="Twitter" href="https://twitter.com/NestleEgypt" target="_blank">
        <area shape="rect" coords="571,45,701,60" alt="" href="<?php echo site_url('welcome'); ?>" target="_blank">
        <area shape="rect" coords="571,79,621,89" alt="" href="#" target="_blank">
        <area shape="rect" coords="482,95,533,110" alt="" href="#" target="_blank">
	</map>
  </tr>
  
</table>   
<style>
  	@import url(http://fonts.googleapis.com/earlyaccess/droidarabickufi.css); 
	h2, h3, p{
		font-family: 'Droid Arabic Kufi', serif;
	}
	h2{
		font-size:16px;
	}
	h3{
		font-size:14px;
	}
  </style>

</body>
</html>