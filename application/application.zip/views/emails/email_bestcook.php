<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link />
</head>

<body style="margin:0; padding:0; font-family:Tahoma, Geneva, sans-serif; font-size:14px;" >




<table width="800"  border="0" cellspacing="0" cellpadding="0" style="margin:0px auto;">
	<tr>
    	<td><img src="<?php echo base_url();?>images/emails/bestcook_header.png" /></td>
    </tr>
    
     	
    	<tr bgcolor="#FFFFFF" align="right">
        	<td style="color:#202b62;font-size:30px;font-family:GE Flow;padding:10px 40px;"> مرحبا رانيا  </td>
        </tr>
        
           <tr>
            	<td><img usemap="#body" src="<?php echo base_url();?>images/emails/bestcook_body.png" /></td>
                <map name="body" id="imgmap201461213363" name="imgmap201461213363">
                <area shape="rect" alt="showarticles" title="" coords="261,163,353,200" href="" target="" />
                </map>
            </tr>
        
    
  
    
    
    
    <tr>
    	<td> <img  usemap="#bestcookfooter"  src="<?php echo base_url();?>images/emails/bestcook_footer.png" /> </td>
        <map  name="bestcookfooter" id="imgmap201461213363" name="imgmap201461213363">
        <area shape="rect" alt="enstlewebsite" title="" coords="566,87,733,104" href="http://www.mynestle.com.eg" target="" />
        <area shape="rect" alt="facebookpage" title="" coords="59,81,95,109"  href="https://www.facebook.com/NestleEgypt" target="" />
        <area shape="rect" alt="twitterpage" title="" coords="26,79,53,109" href="https://www.twitter.com" target="" />
        <area shape="rect" alt="editprofile" title="" coords="572,121,621,136" href="<?php echo site_url('my_corner/profile');?>" target="" />
        <area shape="rect" alt="nomessage" title="" coords="480,136,543,150" href="" target="" />
        </map>
    </tr>
    
</table>




</body>
</html>
