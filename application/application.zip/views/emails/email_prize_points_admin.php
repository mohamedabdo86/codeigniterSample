<span id="message"><?php echo $name; ?> has arrived to the points <?php echo $award_number; ?><br />
and his email is <?php echo $email; ?></span>