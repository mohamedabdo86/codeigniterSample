<script type="text/javascript">
$(document).ready(function() {
	$(".swf").fancybox({
		maxWidth	: 756,
		maxHeight	: 420,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none',
		padding:0
	});
});
</script>
<div align="center">
	<div>
		<img src="<?php echo base_url() ?>images/bestmom/application_food_guide<?php echo $current_language_db_prefix ?>.jpg" usemap="Map<?php echo $current_language_db_prefix ?>" />
	</div>
</div>
<map id="Map" name="Map">
<area shape="rect" coords="103,272,142,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=1" alt="" title="">
<area shape="rect" coords="144,272,183,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=2" alt="" title="">
<area shape="rect" coords="186,272,225,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=3" alt="" title="">
<area shape="rect" coords="226,272,265,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=4" alt="" title="">
<area shape="rect" coords="267,272,306,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=5" alt="" title="">
</map>
 

<map name="Map_ar" id="Map_ar">
<area shape="rect" coords="103,272,142,312" class="swf" style="cursor: pointer;" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=5" alt="" title="">
<area shape="rect" class="swf" coords="144,272,183,312" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=4" alt="" title="">
<area shape="rect" class="swf" coords="186,272,225,312" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=3" alt="" title="">
<area shape="rect" class="swf" coords="226,272,265,312" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=2" alt="" title="">
<area shape="rect" class="swf" coords="267,272,306,312" href="<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/new_day_to_day_app/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=1" alt="" title="">
</map>


<?php /*?><map id="Map" name="Map">
<area shape="rect" coords="103,272,142,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=1" alt="" title="">
<area shape="rect" coords="144,272,183,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=2" alt="" title="">
<area shape="rect" coords="186,272,225,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=3" alt="" title="">
<area shape="rect" coords="226,272,265,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=4" alt="" title="">
<area shape="rect" coords="267,272,306,312" class="swf" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=5" alt="" title="">
</map>
 

<map name="Map_ar" id="Map_ar">
<area shape="rect" coords="103,272,142,312" class="swf" style="cursor: pointer;" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=5" alt="" title="">
<area shape="rect" class="swf" coords="144,272,183,312" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=4" alt="" title="">
<area shape="rect" class="swf" coords="186,272,225,312" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=3" alt="" title="">
<area shape="rect" class="swf" coords="226,272,265,312" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=2" alt="" title="">
<area shape="rect" class="swf" coords="267,272,306,312" href="<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr.swf?dataHandler=&resourcesPath=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/&resourcesXml=<?php echo base_url(); ?>uploads/applications_src/DaytoDay<?php echo $current_language_db_prefix ?>/aqr/aqr.xml&stage=1" alt="" title="">
</map>
<?php */?>