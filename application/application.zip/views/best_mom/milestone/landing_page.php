<script type="text/javascript">
$(document).ready(function() {
	$(".swf").fancybox({
		maxWidth	: 777,
		maxHeight	: 300,
		fitToView	: false,
		width		: 777,
		height		: 300,
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none',
		padding:0
	});
});
</script>
<div align="center">
	<div>
		<img src="<?php echo base_url() ?>images/bestmom/application_child_grow<?php echo $current_language_db_prefix ?>.jpg" usemap="Map<?php echo $current_language_db_prefix ?>" />
	</div>
</div>
<map name="Map" id="Map">
<area shape="circle" class="swf" coords="577,76,32" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestones.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=1">
<area shape="circle" class="swf" coords="617,126,31" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestones.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=2">
<area shape="circle" class="swf" coords="626,199,31" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestones.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=3">
<area shape="circle" class="swf" coords="599,263,33" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestones.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=4">
<area shape="circle" class="swf" coords="533,302,32" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestones.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=5">
</map>

<map name="Map_ar" id="Map_ar">
<area shape="circle" class="swf" coords="132,74,31" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestonesAr.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=1">
<area shape="circle" class="swf" coords="91,124,28" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestonesAr.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=2">
<area shape="circle" class="swf" coords="68,179,28" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestonesAr.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=3">
<area shape="circle" class="swf" coords="82,245,32" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestonesAr.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=4">
<area shape="circle" class="swf" coords="128,298,32" href="<?php echo base_url() ?>uploads/applications_src/growingupmilestonesAr.swf?&resourcesXml=<?php echo base_url() ?>uploads/applications_src/growingupmilestones.xml&resourcesPath=<?php echo base_url() ?>uploads/applications_src/growingupmilestones/&stage=5">
</map>
