<?php


$this->widgets->generate_tab_lists("feat_list_3enaya_betefly",80,$current_language_db_prefix,$current_section_border_color,$current_section_borderbottom_color);
?>