<?php


$this->load->view('template/header');
$this->load->view($target_page);
$this->load->view('template/footer');