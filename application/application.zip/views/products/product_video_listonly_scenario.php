

    <?php
	//load articles/recipes view
	$this->load->view('products/product_articles_recipes');
	
	//load video list view
	$this->load->view('products/products_videos_list');
	
	?>

    