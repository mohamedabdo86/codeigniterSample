  <?php
   	
	/**
	* This file concerns with product footer of Products section
	*/
	
	// Adding Promotions
	$this->load->view('products/product_promotions'); 
   
   	// Adding Poll
	$this->load->view('products/product_poll'); 
   
  	// Adding Videos List 
	$this->load->view('products/products_videos_list'); 
   
   ?>
  
  
   
   </div>
   
                